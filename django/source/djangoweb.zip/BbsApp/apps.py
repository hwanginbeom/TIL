from django.apps import AppConfig


class BbsappConfig(AppConfig):
    name = 'BbsApp'
